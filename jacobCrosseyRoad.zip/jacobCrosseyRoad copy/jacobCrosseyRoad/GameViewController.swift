//
//  GameViewController.swift
//  jacobCrosseyRoad
//
//  Created by Jacob Kaiserman on 11/2/20.
//

import UIKit
import QuartzCore
import SceneKit
import SpriteKit

class GameViewController: UIViewController{
//    setup variables
    var sceneView: SCNView!
    var scene: SCNScene!
    var cameraNode = SCNNode()
    var lightNode = SCNNode()
    var playerNode = SCNNode()
    var collisionNode = CollisionNode()
    var mapNode = SCNNode()
    var lanes=[LaneNode]()
    var lanecount=0
    var jumpForwardAction: SCNAction?
    var jumpRightAction: SCNAction?
    var jumpLeftAction: SCNAction?
    var driveRightAction: SCNAction?
    var driveLeftAction: SCNAction?
    var dieAction: SCNAction?
    var laneCount = 0
    var frontBlocked = false
    var leftBlocked = false
    var rightBlocked = false
    var gameOver = false
    var gameScoreBoard: GameScoreBoard!
    var score = 0
    var blockType = 0
    
    
    
    override func viewDidLoad(){
        super.viewDidLoad()
        initGame()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        setupGestures()
        self.gameScoreBoard = GameScoreBoard(with: self.sceneView.bounds.size,menu: false)
        self.sceneView.overlaySKScene = self.gameScoreBoard
        self.sceneView.overlaySKScene?.isUserInteractionEnabled = false
    }
    
    func updateTraffic(){
//        Make the vehicles move
        for lane in lanes{
            guard let trafficNode = lane.trafficNode else {
                continue
            }
            for vehicle in trafficNode.childNodes{
                if(vehicle.position.x > 10){
                    vehicle.position.x = -10
                }
                else if(vehicle.position.x < -10){
                    vehicle.position.x = 10
                }
            }
        }
    }
    func initGame(){
        //        call all of the functions to setup the game.
                setupScene()
                setupPlayer()
                setupCollisionNode()
                setupFloor()
                setupLanes()
                setupCamera()
                setupLight()
        //        setupGestures()
                setupActions()
                setupTraffic()
    }
    func updatePositions(){
        collisionNode.position = playerNode.position
        let dx = (playerNode.position.x+1-cameraNode.position.x)
        let dz = (playerNode.position.z+2-cameraNode.position.z)
        cameraNode.position.x += dx
        cameraNode.position.z += dz
        lightNode.position = cameraNode.position
    }
    func addActions(for trafficNode: TrafficNode){
        guard let driveAction = driveLeftAction else{
            return
        }
        // Set the speed of the vehicles
        driveAction.speed = 2.0
        for vehicle in trafficNode.childNodes{
            vehicle.removeAllActions()
            vehicle.runAction(driveAction)
        }
    }
    
    func setupTraffic(){
        for lane in lanes{
            if let trafficNode = lane.trafficNode{
                addActions(for: trafficNode)
            }
        }
    }
    func setupScene(){
        // setup the scene and gameScoreBoard
        sceneView = (view as! SCNView)
        sceneView.delegate = self
        scene = SCNScene()
        scene.physicsWorld.contactDelegate = self
        sceneView.present(scene, with: .fade(withDuration:0.5),incomingPointOfView: nil, completionHandler: nil)
        DispatchQueue.main.async {
            self.gameScoreBoard = GameScoreBoard(with: self.sceneView.bounds.size,menu: true)
            self.sceneView.overlaySKScene = self.gameScoreBoard
            self.sceneView.overlaySKScene?.isUserInteractionEnabled = false
        }
        sceneView.scene = scene
        scene.rootNode.addChildNode(mapNode)
    }
    func setupLanes(){
        // create grass and road lanes
        for i in 1...20 {
            if(i % 2 == 0){
                createNewLaneEx(type:LaneType.grass)
            }
            else{
                createNewLaneEx(type:LaneType.road)
            }
            
            
        }
    }
    
    func setupFloor(){
        //setup floor (same for all scene kit games)
        let floor = SCNFloor()
        floor.firstMaterial?.diffuse.contents = UIImage(named: "art.scnassets/darkgrass.png")
        floor.firstMaterial?.diffuse.wrapS = .repeat
        floor.firstMaterial?.diffuse.wrapT = .repeat
        floor.firstMaterial?.diffuse.contentsTransform = SCNMatrix4MakeScale(0.5, 0.5, 0.5)
        floor.reflectivity = 0.0
        let floorNode = SCNNode(geometry: floor)
        scene.rootNode.addChildNode(floorNode)
        
    }
    
    func setupCamera(){
        //setup camera (same for all scene kit games)
        cameraNode.camera = SCNCamera()
        cameraNode.position = SCNVector3(0.0, 10.0, 0.0)
        cameraNode.eulerAngles = SCNVector3(-toRadians(angle: 60), toRadians(angle: 20), 0)
        scene.rootNode.addChildNode(cameraNode)
    }
    
    func setupLight(){
        //setup light (same for all scene kit games)
        let ambientNode = SCNNode()
        ambientNode.light = SCNLight()
        ambientNode.light?.type = .ambient
        
        let directionalNode = SCNNode()
        directionalNode.light = SCNLight()
        directionalNode.light?.type = .directional
        directionalNode.light?.castsShadow = true
        directionalNode.light?.shadowColor = UIColor(red: 0.4, green: 0.4, blue: 0.4, alpha: 1)
        directionalNode.position = SCNVector3(x: -5, y: 5, z: 0)
        directionalNode.eulerAngles = SCNVector3(x: 0, y: -toRadians(angle: 90), z: -toRadians(angle: 45))
        
        lightNode.addChildNode(ambientNode)
        lightNode.addChildNode(directionalNode)
        lightNode.position = cameraNode.position
        scene.rootNode.addChildNode(lightNode)
        
    }
    func setupPlayer(){
        //setup player (same for all scene kit games)
        guard let playerScene = SCNScene(named: "art.scnassets/Chicken.scn") else { return }
        if let player = playerScene.rootNode.childNode(withName: "player", recursively: true) {
            playerNode = player
            playerNode.position = SCNVector3(x: 0, y: 0.3, z: 0)
            scene.rootNode.addChildNode(playerNode)
        }
        
    }
    
    func setupCollisionNode(){
//        setup collision node(collisionNode.swift)
        collisionNode = CollisionNode()
        collisionNode.position = playerNode.position
        scene.rootNode.addChildNode(collisionNode)
    }
    func setupGestures(){
//        setup the gestures swipe up, swipe left, 
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe))
        swipeUp.direction = .up
        sceneView.addGestureRecognizer(swipeUp)
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe))
        swipeRight.direction = .right
        sceneView.addGestureRecognizer(swipeRight)
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe))
        swipeLeft.direction = .left
        sceneView.addGestureRecognizer(swipeLeft)
        
    }
    func setupActions(){
        let moveUpAction = SCNAction.moveBy(x: 0, y: 1.0, z: 0, duration: 0.1)
        let moveDownAction = SCNAction.moveBy(x: 0, y: -1.0, z: 0, duration: 0.1)
        moveUpAction.timingMode = .easeOut
        moveDownAction.timingMode = .easeIn
        let jumpAction = SCNAction.sequence([moveUpAction, moveDownAction])
        
        let moveForwardAction = SCNAction.moveBy(x: 0, y: 0, z: -1.0, duration: 0.2)
        let moveRightAction = SCNAction.moveBy(x: 1.0, y: 0, z: 0, duration: 0.2)
        let moveLeftAction = SCNAction.moveBy(x: -1.0, y: 0, z: 0, duration: 0.2)
        
        let turnForwardAction = SCNAction.rotateTo(x: 0, y: toRadians(angle: 180), z: 0, duration: 0.2, usesShortestUnitArc: true)
        let turnRightAction = SCNAction.rotateTo(x: 0, y: toRadians(angle: 90), z: 0, duration: 0.2, usesShortestUnitArc: true)
        let turnLeftAction = SCNAction.rotateTo(x: 0, y: -toRadians(angle: 90), z: 0, duration: 0.2, usesShortestUnitArc: true)
        
        jumpForwardAction = SCNAction.group([turnForwardAction, jumpAction, moveForwardAction])
        jumpRightAction = SCNAction.group([turnRightAction, jumpAction, moveRightAction])
        jumpLeftAction = SCNAction.group([turnLeftAction, jumpAction, moveLeftAction])
        
        driveRightAction = SCNAction.repeatForever(SCNAction.moveBy(x:1.0, y:0, z:0, duration: 1.0))
        driveLeftAction = SCNAction.repeatForever(SCNAction.moveBy(x:-1, y:0, z:0, duration: 1.0))
        dieAction = SCNAction.moveBy(x:0,y:5,z:0, duration: 1.0)
        
    }
    func jumpForward(){
        if let action = jumpForwardAction{
            playerNode.runAction(action,completionHandler:{
                
                self.score+=1
                self.gameScoreBoard.pointsLabel?.text = "\(self.score)"
                
            })
        }
    }
    func createNewLane(){
        //        let type = randomBool(odds: 3) ? LaneType.grass : LaneType.road
        let type = LaneType.grass
        let lane = LaneNode(type: type, width: 21.0)
        lane.position = SCNVector3(0, 0, 5 - Float(laneCount))
        laneCount += 1
        lanes.append(lane)
        mapNode.addChildNode(lane)
    }
    func gameEnd(){
        if let gestureRecognizers = self.sceneView.gestureRecognizers {
            for recognizer in gestureRecognizers{
                self.sceneView.removeGestureRecognizer(recognizer)
            }
        }
        if let action = dieAction{
            playerNode.runAction(action,completionHandler: {
                self.resetGame()
            })
            
        }
    }
    func resetGame(){
//        floorNode.removeFromParentNode()
        scene.rootNode.enumerateChildNodes{ (node,_) in
        node.removeFromParentNode()
            
        }
        scene = nil
        gameOver = false
        lanecount = 0
        score = 0
        lanes = [LaneNode]()
        initGame()
        
    }
    func createNewLaneEx(type:LaneType){
        //        let type = randomBool(odds: 3) ? LaneType.grass : LaneType.road
        //        let type = LaneType.grass
        let lane = LaneNode(type: type, width: 21.0)
        lane.position = SCNVector3(0, 0, 5 - Float(laneCount))
        laneCount += 1
        lanes.append(lane)
        mapNode.addChildNode(lane)
    }

    
}
extension GameViewController: SCNSceneRendererDelegate {
    func renderer(_ renderer: SCNSceneRenderer, didApplyAnimationsAtTime time: TimeInterval) {
        updateTraffic()
        updatePositions()
    }
}
extension GameViewController: SCNPhysicsContactDelegate {
    func physicsWorld(_ world: SCNPhysicsWorld, didBegin contact: SCNPhysicsContact) {
     
        
        guard let A = contact.nodeA.physicsBody?.categoryBitMask,let B = contact.nodeB.physicsBody?.categoryBitMask else {return}
        let mask = A | B;
        switch mask{
        
        case PhysicsCategory.vegetation|PhysicsCategory.collisionTestFront:
            frontBlocked = true
        
        case PhysicsCategory.vegetation|PhysicsCategory.collisionTestLeft:
            leftBlocked = true
            
        case PhysicsCategory.vegetation|PhysicsCategory.collisionTestRight:
            rightBlocked = true
        case PhysicsCategory.vehicle|PhysicsCategory.chicken:
            gameOver = true
            gameEnd()
        default:
            break
        }
    }
    
}

extension GameViewController {
    
    func checkBlocks(){
        if scene.physicsWorld.contactTest(with: collisionNode.front.physicsBody!,options:nil).isEmpty{
            blockType = 1
            frontBlocked = false
        }
        else if scene.physicsWorld.contactTest(with: collisionNode.left.physicsBody!,options:nil).isEmpty{
            blockType = 2
            leftBlocked = false
        }
        else if scene.physicsWorld.contactTest(with: collisionNode.right.physicsBody!,options:nil).isEmpty{
            blockType = 3
            rightBlocked = false
        }
    }
    
    @objc func handleSwipe(sender: UISwipeGestureRecognizer) {
        
        switch sender.direction {
        case UISwipeGestureRecognizer.Direction.up:
            jumpForward()
            
        case UISwipeGestureRecognizer.Direction.right:
            if playerNode.position.x < 10 && !rightBlocked{
                if let action = jumpRightAction {
                    playerNode.runAction(action,completionHandler: {
                        self.checkBlocks()
                    })
                    
                }
            }
        case UISwipeGestureRecognizer.Direction.left:
            if playerNode.position.x > -10 {
                if let action = jumpLeftAction {
                    playerNode.runAction(action,completionHandler: {
                        self.checkBlocks()
                    })
                }
            }
        default:
            break
        }
        
    }
    
}
