//
//  laneNode.swift
//  jacobCrosseyRoad
//
//  Created by Jacob Kaiserman on 11/9/20.
//

import Foundation
import SceneKit
enum LaneType {
    case grass, road
}
class TrafficNode: SCNNode{
    let type:Int
//    let laneNumber: Int
//    init(type:Int,laneNumber:Int){
    init(type:Int){
        self.type = type
        super.init()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
class LaneNode: SCNNode {
    let type: LaneType
    
    var trafficNode: TrafficNode?
    init(type: LaneType, width:CGFloat){
        self.type = type
        super.init()
        switch type {
        case .road:
            guard let texture = UIImage(named: "art.scnassets/asphalt") else { break }
            trafficNode = TrafficNode(type: Int(arc4random_uniform(3)))
           addChildNode(trafficNode!)
            createLane(width: width, height: 0.4, image: texture)
        case .grass:
            guard let texture = UIImage(named: "art.scnassets/grass.png") else { break }
            createLane(width: width, height: 0.5, image: texture)
        }
        
    }
    func addElements(_ width:CGFloat,_ laneNode: SCNNode){
       if(type == .road){
        for index in 0..<Int(width){
            guard let trafficNode = trafficNode else {continue}
            if (randomBool(odds:10)){
            let vehicle = getVehicle(for: trafficNode.type)
            
            vehicle.position = SCNVector3(10 - Float(index), 0, 0)
            let yAngle: CGFloat = toRadians(angle: 180)
            vehicle.eulerAngles = SCNVector3(0,yAngle,0)
            trafficNode.addChildNode(vehicle)
            }
        }
       }
       else if(type == .grass){
            for index in 0..<Int(width){
                if randomBool(odds: 10){
                    let vegetation = getVegetation()
                    vegetation.position = SCNVector3(10 - Float(index), 0, 0)
                    laneNode.addChildNode(vegetation)
                }
            }
        
       }
    }
    func getVegetation() -> SCNNode{
        let vegetation = randomBool(odds: 2) ? Models.tree.clone() : Models.hedge.clone()
        return vegetation
    }
    
    //let blueTruckScene = SCNScene(named: "art.scnassets/BlueTruck.scn")!
    //let blueTruck = blueTruckScene.rootNode.childNode(withName: "truck", recursively: true)
    func createLane(width: CGFloat, height: CGFloat, image: UIImage) {
        
        let laneGeometry = SCNBox(width: width, height: height, length: 1, chamferRadius: 0.0)
        laneGeometry.firstMaterial?.diffuse.contents = image
        laneGeometry.firstMaterial?.diffuse.wrapT = .repeat
        laneGeometry.firstMaterial?.diffuse.wrapS = .repeat
        laneGeometry.firstMaterial?.diffuse.contentsTransform = SCNMatrix4MakeScale(Float(width), 1.0, 1.0)
        
        let laneNode = SCNNode(geometry: laneGeometry)
        addChildNode(laneNode)
        addElements(width,laneNode)
    }
    func getVehicle(for type:Int) -> SCNNode{
        switch type{
        case 0:
            return Models.car.clone()
        case 1:
            return Models.blueTruck.clone()
        case 2:
            return Models.firetruck.clone()
        default:
            return Models.car.clone()
        }
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
