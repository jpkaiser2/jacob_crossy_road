//
//  gameScore.swift
//  jacobCrosseyRoad
//
//  Created by Jacob Kaiserman on 12/14/20.
//

import Foundation
import SpriteKit


class GameScoreBoard: SKScene{
    var pointsLabel: SKLabelNode?
    var titleLabel: SKLabelNode?
    var splashLabel: SKLabelNode?
    init(with size: CGSize, menu:Bool) {
        super.init(size: size)
        if(menu == true){
            addSplashLabel()
        }
        else{
            addPointsLabel()
        }
//        addPointsLabel()
//        addSplashLabel()
    }
    
    func addPointsLabel(){
        pointsLabel = SKLabelNode(fontNamed: "8BIT WONDER Nominal")
        guard let pointsLabel = pointsLabel else{return}
        pointsLabel.text = "0"
        pointsLabel.fontSize = 25.0
        pointsLabel.position = CGPoint(x:frame.minX+pointsLabel.frame.size.width, y:frame.maxY-pointsLabel.frame.size.height*2)
        addChild(pointsLabel)
        
        titleLabel = SKLabelNode(fontNamed: "8BIT WONDER Nominal")
        guard let titleLabel = titleLabel else{return}
        titleLabel.text = "Jacob Crossy Road"
        titleLabel.fontSize = 22.0
        titleLabel.position = CGPoint(x:frame.minX+titleLabel.frame.size.width, y:frame.maxY-titleLabel.frame.size.height*1.7)
        addChild(titleLabel)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func addSplashLabel(){
        titleLabel = SKLabelNode(fontNamed: "8BIT WONDER Nominal")
        guard let titleLabel = titleLabel else{return}
        titleLabel.text = "Jacob Crossy Road"
        titleLabel.fontSize = 22.0
        titleLabel.position = CGPoint(x:frame.minX+titleLabel.frame.size.width, y:frame.maxY-titleLabel.frame.size.height*1.7)
        addChild(titleLabel)
        
        splashLabel = SKLabelNode(fontNamed: "8BIT WONDER Nominal")
        guard let splashLabel = splashLabel else{return}
        splashLabel.text = "Tap to play"
        splashLabel.fontSize = 22.0
        splashLabel.position = CGPoint(x:frame.minX+splashLabel.frame.size.width, y:frame.maxY-splashLabel.frame.size.height*9)
        addChild(splashLabel)
        
    }

    
}
